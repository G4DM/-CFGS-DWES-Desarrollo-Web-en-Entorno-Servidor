<?php
class Config {
	static public $mvc_bd_hostname = 'localhost';
	static public $mvc_bd_nombre = 'alimentos';
	static public $mvc_bd_usuario = 'dani';
	static public $mvc_bd_clave = 'dani';
	static public $mvc_vis_css = 'estilo.css';
}
?>